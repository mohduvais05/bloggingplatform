import { StyleSheet, TouchableOpacity, Text } from 'react-native';
import { useTheme } from '@/hooks/useTheme';

interface CategoryPillProps {
  category: string;
  isSelected: boolean;
  onPress: () => void;
}

export default function CategoryPill({ category, isSelected, onPress }: CategoryPillProps) {
  const { colors } = useTheme();
  
  return (
    <TouchableOpacity 
      style={[
        styles.container, 
        { 
          backgroundColor: isSelected ? colors.primary : colors.cardBackground,
          borderColor: isSelected ? colors.primary : colors.border
        }
      ]}
      activeOpacity={0.8}
      onPress={onPress}
    >
      <Text 
        style={[
          styles.text,
          { color: isSelected ? 'white' : colors.text }
        ]}
      >
        {category}
      </Text>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  container: {
    paddingVertical: 8,
    paddingHorizontal: 16,
    borderRadius: 20,
    borderWidth: 1,
    marginRight: 8,
    marginBottom: 8,
  },
  text: {
    fontFamily: 'Inter-Medium',
    fontSize: 14,
  },
});