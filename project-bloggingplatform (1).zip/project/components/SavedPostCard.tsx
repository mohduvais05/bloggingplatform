import { StyleSheet, TouchableOpacity, Text, View } from 'react-native';
import { Image } from 'expo-image';
import { Post } from '@/types';
import { useTheme } from '@/hooks/useTheme';
import { Bookmark, X } from 'lucide-react-native';

interface SavedPostCardProps {
  post: Post;
  onPress: () => void;
  onRemove: () => void;
}

export default function SavedPostCard({ post, onPress, onRemove }: SavedPostCardProps) {
  const { colors } = useTheme();
  
  return (
    <TouchableOpacity 
      style={[styles.container, { backgroundColor: colors.cardBackground, borderColor: colors.border }]}
      activeOpacity={0.8}
      onPress={onPress}
    >
      <View style={styles.contentContainer}>
        {post.coverImage && (
          <Image
            source={{ uri: post.coverImage }}
            style={styles.thumbnail}
            contentFit="cover"
          />
        )}
        
        <View style={styles.postInfo}>
          <Text style={[styles.category, { color: colors.primary }]}>
            {post.category}
          </Text>
          <Text style={[styles.title, { color: colors.text }]} numberOfLines={2}>
            {post.title}
          </Text>
          <Text style={[styles.authorName, { color: colors.textSecondary }]}>
            {post.author?.name || 'Unknown Author'} · {new Date(post.createdAt).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}
          </Text>
        </View>
        
        <TouchableOpacity 
          style={styles.removeButton}
          onPress={onRemove}
          hitSlop={{ top: 10, right: 10, bottom: 10, left: 10 }}
        >
          <X size={18} color={colors.textSecondary} />
        </TouchableOpacity>
      </View>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  container: {
    borderRadius: 12,
    marginBottom: 12,
    borderWidth: 1,
    overflow: 'hidden',
  },
  contentContainer: {
    flexDirection: 'row',
    padding: 12,
  },
  thumbnail: {
    width: 60,
    height: 60,
    borderRadius: 8,
    marginRight: 12,
  },
  postInfo: {
    flex: 1,
  },
  category: {
    fontSize: 12,
    fontFamily: 'Inter-SemiBold',
    marginBottom: 4,
  },
  title: {
    fontSize: 15,
    fontFamily: 'Merriweather-Bold',
    marginBottom: 4,
  },
  authorName: {
    fontSize: 12,
    fontFamily: 'Inter-Regular',
  },
  removeButton: {
    padding: 4,
  },
});