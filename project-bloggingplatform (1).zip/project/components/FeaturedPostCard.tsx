import { StyleSheet, TouchableOpacity, Text, View, Dimensions } from 'react-native';
import { Image } from 'expo-image';
import { LinearGradient } from 'expo-linear-gradient';
import { Post } from '@/types';
import { useTheme } from '@/hooks/useTheme';

const { width } = Dimensions.get('window');
const CARD_WIDTH = width * 0.85;

interface FeaturedPostCardProps {
  post: Post;
  onPress: () => void;
}

export default function FeaturedPostCard({ post, onPress }: FeaturedPostCardProps) {
  const { colors } = useTheme();
  
  return (
    <TouchableOpacity 
      style={styles.container}
      activeOpacity={0.9}
      onPress={onPress}
    >
      <Image
        source={{ uri: post.coverImage || 'https://images.pexels.com/photos/2662116/pexels-photo-2662116.jpeg' }}
        style={styles.image}
        contentFit="cover"
      />
      
      <LinearGradient
        colors={['transparent', 'rgba(0,0,0,0.8)']}
        style={styles.gradient}
      >
        <View style={styles.contentContainer}>
          <View style={styles.categoryContainer}>
            <Text style={styles.category}>{post.category}</Text>
          </View>
          
          <Text style={styles.title} numberOfLines={2}>
            {post.title}
          </Text>
          
          <View style={styles.authorRow}>
            <Image
              source={{ uri: post.author?.avatar || 'https://via.placeholder.com/32' }}
              style={styles.authorImage}
            />
            <View>
              <Text style={styles.authorName}>
                {post.author?.name || 'Unknown Author'}
              </Text>
              <Text style={styles.postDate}>
                {new Date(post.createdAt).toLocaleDateString('en-US', { 
                  year: 'numeric', 
                  month: 'short', 
                  day: 'numeric' 
                })}
              </Text>
            </View>
          </View>
        </View>
      </LinearGradient>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  container: {
    width: CARD_WIDTH,
    height: 280,
    borderRadius: 16,
    overflow: 'hidden',
    marginRight: 16,
  },
  image: {
    width: '100%',
    height: '100%',
  },
  gradient: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    height: '70%',
    justifyContent: 'flex-end',
  },
  contentContainer: {
    padding: 16,
  },
  categoryContainer: {
    marginBottom: 8,
  },
  category: {
    color: 'white',
    fontSize: 12,
    fontFamily: 'Inter-SemiBold',
    paddingHorizontal: 10,
    paddingVertical: 4,
    backgroundColor: 'rgba(255, 255, 255, 0.25)',
    borderRadius: 16,
    overflow: 'hidden',
    alignSelf: 'flex-start',
  },
  title: {
    color: 'white',
    fontSize: 20,
    fontFamily: 'Merriweather-Bold',
    marginBottom: 12,
  },
  authorRow: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  authorImage: {
    width: 32,
    height: 32,
    borderRadius: 16,
    marginRight: 8,
    borderWidth: 1,
    borderColor: 'rgba(255, 255, 255, 0.5)',
  },
  authorName: {
    color: 'white',
    fontSize: 14,
    fontFamily: 'Inter-Medium',
  },
  postDate: {
    color: 'rgba(255, 255, 255, 0.8)',
    fontSize: 12,
    fontFamily: 'Inter-Regular',
  },
});