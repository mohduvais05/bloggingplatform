import { useState } from 'react';
import { View, TextInput, TouchableOpacity, StyleSheet, Keyboard } from 'react-native';
import { useTheme } from '@/hooks/useTheme';
import { useAuth } from '@/hooks/useAuth';
import { Send } from 'lucide-react-native';
import { addComment } from '@/api/posts';
import { Comment } from '@/types';

interface CommentInputProps {
  postId: number;
  onCommentAdded: (comment: Comment) => void;
}

export default function CommentInput({ postId, onCommentAdded }: CommentInputProps) {
  const [comment, setComment] = useState('');
  const [loading, setLoading] = useState(false);
  
  const { colors } = useTheme();
  const { user } = useAuth();
  
  const handleSubmit = async () => {
    if (!comment.trim()) return;
    
    setLoading(true);
    try {
      const newComment = await addComment(postId, comment);
      onCommentAdded(newComment);
      setComment('');
      Keyboard.dismiss();
    } catch (error) {
      console.error('Error adding comment:', error);
    } finally {
      setLoading(false);
    }
  };
  
  return (
    <View style={[styles.container, { backgroundColor: colors.cardBackground, borderColor: colors.border }]}>
      <TextInput
        style={[styles.input, { color: colors.text }]}
        placeholder="Write a comment..."
        placeholderTextColor={colors.textSecondary}
        value={comment}
        onChangeText={setComment}
        multiline
      />
      <TouchableOpacity 
        style={[styles.sendButton, { backgroundColor: colors.primary, opacity: (!comment.trim() || loading) ? 0.5 : 1 }]}
        onPress={handleSubmit}
        disabled={!comment.trim() || loading}
      >
        <Send size={18} color="white" />
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderWidth: 1,
    borderRadius: 24,
  },
  input: {
    flex: 1,
    fontFamily: 'Inter-Regular',
    fontSize: 14,
    paddingHorizontal: 8,
    maxHeight: 80,
    minHeight: 36,
  },
  sendButton: {
    width: 36,
    height: 36,
    borderRadius: 18,
    justifyContent: 'center',
    alignItems: 'center',
    marginLeft: 8,
  },
});