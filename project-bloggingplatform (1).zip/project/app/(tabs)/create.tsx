import { useState, useRef, useEffect } from 'react';
import { View, Text, StyleSheet, TextInput, TouchableOpacity, ScrollView, KeyboardAvoidingView, Platform } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Image } from 'expo-image';
import * as ImagePicker from 'expo-image-picker';
import { useRouter } from 'expo-router';
import { useTheme } from '@/hooks/useTheme';
import { WebView } from 'react-native-webview';
import { Bold, Italic, Link, List, Image as ImageIcon, ChevronLeft, SquareCheck as CheckSquare } from 'lucide-react-native';
import { createPost } from '@/api/posts';
import { Post } from '@/types';

type EditorCommand = 'bold' | 'italic' | 'link' | 'list' | 'image';

export default function CreateScreen() {
  const [title, setTitle] = useState('');
  const [content, setContent] = useState('');
  const [coverImage, setCoverImage] = useState<string | null>(null);
  const [category, setCategory] = useState('');
  const [availableCategories] = useState(['Technology', 'Health', 'Travel', 'Food', 'Lifestyle', 'Business']);
  const [step, setStep] = useState<'details' | 'content'>('details');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  
  const webViewRef = useRef<WebView>(null);
  const { colors } = useTheme();
  const router = useRouter();
  
  useEffect(() => {
    (async () => {
      const { status } = await ImagePicker.requestMediaLibraryPermissionsAsync();
      if (status !== 'granted') {
        setError('Permission to access media library is required!');
      }
    })();
  }, []);
  
  const pickImage = async () => {
    const result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.Images,
      allowsEditing: true,
      aspect: [16, 9],
      quality: 0.7,
    });
    
    if (!result.canceled) {
      setCoverImage(result.assets[0].uri);
    }
  };
  
  const handleEditorCommand = (command: EditorCommand) => {
    if (command === 'image') {
      // Add image uploader logic here
    } else {
      // Send command to WebView editor
      const javascriptToInject = `
        document.execCommand('${command}');
        true;
      `;
      webViewRef.current?.injectJavaScript(javascriptToInject);
    }
  };
  
  const handleNext = () => {
    if (!title.trim()) {
      setError('Title is required');
      return;
    }
    
    if (!category) {
      setError('Please select a category');
      return;
    }
    
    setError('');
    setStep('content');
  };
  
  const handlePublish = async () => {
    if (!content.trim()) {
      setError('Content cannot be empty');
      return;
    }
    
    setError('');
    setLoading(true);
    
    try {
      // In a real app, you'd save the post to your backend
      await createPost({
        title,
        content,
        coverImage,
        category,
      });
      
      router.replace('/(tabs)');
    } catch (err) {
      setError('Failed to publish post. Please try again.');
    } finally {
      setLoading(false);
    }
  };
  
  const renderDetailsStep = () => (
    <ScrollView contentContainerStyle={styles.detailsContainer}>
      <Text style={[styles.inputLabel, { color: colors.text }]}>Title</Text>
      <TextInput
        style={[styles.titleInput, { color: colors.text, borderColor: colors.border }]}
        placeholder="Enter your blog title"
        placeholderTextColor={colors.textSecondary}
        value={title}
        onChangeText={setTitle}
        maxLength={100}
      />
      
      <Text style={[styles.inputLabel, { color: colors.text, marginTop: 24 }]}>Cover Image</Text>
      <TouchableOpacity 
        style={[styles.coverImageContainer, { borderColor: colors.border }]}
        onPress={pickImage}
      >
        {coverImage ? (
          <Image
            source={{ uri: coverImage }}
            style={styles.coverImage}
            contentFit="cover"
          />
        ) : (
          <View style={styles.coverImagePlaceholder}>
            <ImageIcon size={24} color={colors.textSecondary} />
            <Text style={[styles.coverImageText, { color: colors.textSecondary }]}>
              Tap to add a cover image
            </Text>
          </View>
        )}
      </TouchableOpacity>
      
      <Text style={[styles.inputLabel, { color: colors.text, marginTop: 24 }]}>Category</Text>
      <View style={styles.categoriesContainer}>
        {availableCategories.map((cat) => (
          <TouchableOpacity
            key={cat}
            style={[
              styles.categoryPill,
              { 
                backgroundColor: category === cat ? colors.primary : colors.cardBackground,
                borderColor: colors.border
              }
            ]}
            onPress={() => setCategory(cat)}
          >
            <Text
              style={[
                styles.categoryText,
                { color: category === cat ? 'white' : colors.text }
              ]}
            >
              {cat}
            </Text>
          </TouchableOpacity>
        ))}
      </View>
      
      <TouchableOpacity
        style={[styles.nextButton, { backgroundColor: colors.primary }]}
        onPress={handleNext}
      >
        <Text style={styles.nextButtonText}>Next</Text>
      </TouchableOpacity>
    </ScrollView>
  );
  
  const renderContentStep = () => (
    <KeyboardAvoidingView 
      style={styles.contentContainer}
      behavior={Platform.OS === 'ios' ? 'padding' : undefined}
      keyboardVerticalOffset={Platform.OS === 'ios' ? 88 : 0}
    >
      <View style={styles.toolbar}>
        <TouchableOpacity 
          style={styles.toolbarButton} 
          onPress={() => handleEditorCommand('bold')}
        >
          <Bold size={20} color={colors.text} />
        </TouchableOpacity>
        <TouchableOpacity 
          style={styles.toolbarButton} 
          onPress={() => handleEditorCommand('italic')}
        >
          <Italic size={20} color={colors.text} />
        </TouchableOpacity>
        <TouchableOpacity 
          style={styles.toolbarButton} 
          onPress={() => handleEditorCommand('link')}
        >
          <Link size={20} color={colors.text} />
        </TouchableOpacity>
        <TouchableOpacity 
          style={styles.toolbarButton} 
          onPress={() => handleEditorCommand('list')}
        >
          <List size={20} color={colors.text} />
        </TouchableOpacity>
        <TouchableOpacity 
          style={styles.toolbarButton} 
          onPress={() => handleEditorCommand('image')}
        >
          <ImageIcon size={20} color={colors.text} />
        </TouchableOpacity>
      </View>
      
      <View style={[styles.editorContainer, { borderColor: colors.border }]}>
        {Platform.OS === 'web' ? (
          <TextInput
            style={[styles.contentInput, { color: colors.text }]}
            placeholder="Write your blog post here..."
            placeholderTextColor={colors.textSecondary}
            value={content}
            onChangeText={setContent}
            multiline
            textAlignVertical="top"
          />
        ) : (
          <WebView
            ref={webViewRef}
            source={{ html: getEditorHTML(colors) }}
            style={{ flex: 1, backgroundColor: 'transparent' }}
            onMessage={(event) => {
              setContent(event.nativeEvent.data);
            }}
          />
        )}
      </View>
      
      <View style={styles.publishContainer}>
        <TouchableOpacity
          style={[styles.backToDetailsButton, { borderColor: colors.border }]}
          onPress={() => setStep('details')}
        >
          <Text style={[styles.backToDetailsText, { color: colors.text }]}>Back</Text>
        </TouchableOpacity>
        
        <TouchableOpacity
          style={[styles.publishButton, { backgroundColor: colors.primary, opacity: loading ? 0.7 : 1 }]}
          onPress={handlePublish}
          disabled={loading}
        >
          <Text style={styles.publishButtonText}>{loading ? 'Publishing...' : 'Publish'}</Text>
        </TouchableOpacity>
      </View>
    </KeyboardAvoidingView>
  );

  return (
    <SafeAreaView style={[styles.container, { backgroundColor: colors.background }]}>
      <View style={styles.header}>
        {step === 'content' ? (
          <TouchableOpacity onPress={() => setStep('details')}>
            <ChevronLeft size={24} color={colors.text} />
          </TouchableOpacity>
        ) : (
          <TouchableOpacity onPress={() => router.back()}>
            <ChevronLeft size={24} color={colors.text} />
          </TouchableOpacity>
        )}
        
        <Text style={[styles.headerTitle, { color: colors.text }]}>
          {step === 'details' ? 'Create a new post' : 'Write your content'}
        </Text>
        
        <View style={{ width: 24 }} />
      </View>
      
      {error ? (
        <View style={[styles.errorContainer, { backgroundColor: 'rgba(239, 68, 68, 0.1)' }]}>
          <Text style={styles.errorText}>{error}</Text>
        </View>
      ) : null}
      
      {step === 'details' ? renderDetailsStep() : renderContentStep()}
    </SafeAreaView>
  );
}

const getEditorHTML = (colors: any) => `
<!DOCTYPE html>
<html>
<head>
  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
  <style>
    body {
      font-family: system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif;
      margin: 0;
      padding: 8px;
      color: ${colors.text};
      background-color: ${colors.background};
      min-height: 100%;
    }
    div#editor {
      outline: none;
      padding: 8px;
      min-height: 200px;
    }
  </style>
</head>
<body>
  <div id="editor" contenteditable="true"></div>
  <script>
    const editor = document.getElementById('editor');
    editor.addEventListener('input', function() {
      window.ReactNativeWebView.postMessage(editor.innerHTML);
    });
  </script>
</body>
</html>
`;

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 24,
    paddingVertical: 16,
  },
  headerTitle: {
    fontSize: 18,
    fontFamily: 'Inter-SemiBold',
  },
  errorContainer: {
    marginHorizontal: 24,
    marginBottom: 16,
    padding: 12,
    borderRadius: 8,
  },
  errorText: {
    color: '#EF4444',
    fontFamily: 'Inter-Medium',
    fontSize: 14,
  },
  detailsContainer: {
    padding: 24,
  },
  inputLabel: {
    fontSize: 16,
    fontFamily: 'Inter-Medium',
    marginBottom: 8,
  },
  titleInput: {
    height: 56,
    borderWidth: 1,
    borderRadius: 8,
    paddingHorizontal: 16,
    fontFamily: 'Inter-Regular',
    fontSize: 16,
  },
  coverImageContainer: {
    height: 200,
    borderWidth: 1,
    borderRadius: 8,
    overflow: 'hidden',
  },
  coverImage: {
    width: '100%',
    height: '100%',
  },
  coverImagePlaceholder: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  coverImageText: {
    fontFamily: 'Inter-Regular',
    marginTop: 8,
  },
  categoriesContainer: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    marginTop: 8,
  },
  categoryPill: {
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 20,
    marginRight: 8,
    marginBottom: 8,
    borderWidth: 1,
  },
  categoryText: {
    fontFamily: 'Inter-Medium',
    fontSize: 14,
  },
  nextButton: {
    height: 56,
    justifyContent: 'center',
    alignItems: 'center',
    borderRadius: 8,
    marginTop: 32,
  },
  nextButtonText: {
    color: 'white',
    fontSize: 16,
    fontFamily: 'Inter-SemiBold',
  },
  contentContainer: {
    flex: 1,
    padding: 24,
  },
  toolbar: {
    flexDirection: 'row',
    marginBottom: 16,
  },
  toolbarButton: {
    width: 40,
    height: 40,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 8,
  },
  editorContainer: {
    flex: 1,
    borderWidth: 1,
    borderRadius: 8,
    marginBottom: 16,
  },
  contentInput: {
    flex: 1,
    padding: 16,
    fontFamily: 'Inter-Regular',
    fontSize: 16,
    textAlignVertical: 'top',
  },
  publishContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  backToDetailsButton: {
    height: 56,
    paddingHorizontal: 24,
    justifyContent: 'center',
    alignItems: 'center',
    borderRadius: 8,
    borderWidth: 1,
    width: '30%',
  },
  backToDetailsText: {
    fontSize: 16,
    fontFamily: 'Inter-Medium',
  },
  publishButton: {
    height: 56,
    justifyContent: 'center',
    alignItems: 'center',
    borderRadius: 8,
    width: '65%',
  },
  publishButtonText: {
    color: 'white',
    fontSize: 16,
    fontFamily: 'Inter-SemiBold',
  },
});