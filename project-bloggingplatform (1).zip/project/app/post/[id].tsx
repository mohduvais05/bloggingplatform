import { useState, useEffect } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, ActivityIndicator } from 'react-native';
import { useLocalSearchParams, useRouter, Stack } from 'expo-router';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Image } from 'expo-image';
import { useTheme } from '@/hooks/useTheme';
import { Heart, MessageCircle, Bookmark, Share2, ChevronLeft, MoveVertical as MoreVertical } from 'lucide-react-native';
import { fetchPostById, likePost, savePost } from '@/api/posts';
import { Post, Comment } from '@/types';
import CommentList from '@/components/CommentList';
import CommentInput from '@/components/CommentInput';

export default function PostDetailScreen() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const [post, setPost] = useState<Post | null>(null);
  const [comments, setComments] = useState<Comment[]>([]);
  const [loading, setLoading] = useState(true);
  const [liked, setLiked] = useState(false);
  const [saved, setSaved] = useState(false);
  const [likesCount, setLikesCount] = useState(0);
  const [commentsCount, setCommentsCount] = useState(0);
  const [showComments, setShowComments] = useState(false);
  
  const { colors } = useTheme();
  const router = useRouter();
  
  useEffect(() => {
    if (id) {
      loadPost(parseInt(id));
    }
  }, [id]);
  
  const loadPost = async (postId: number) => {
    setLoading(true);
    try {
      const postData = await fetchPostById(postId);
      setPost(postData);
      setComments(postData.comments || []);
      setLiked(postData.isLiked || false);
      setSaved(postData.isSaved || false);
      setLikesCount(postData.likesCount || 0);
      setCommentsCount(postData.comments?.length || 0);
    } catch (error) {
      console.error('Error loading post:', error);
    } finally {
      setLoading(false);
    }
  };
  
  const handleLike = async () => {
    try {
      await likePost(post!.id);
      setLiked(!liked);
      setLikesCount(prev => liked ? prev - 1 : prev + 1);
    } catch (error) {
      console.error('Error liking post:', error);
    }
  };
  
  const handleSave = async () => {
    try {
      await savePost(post!.id);
      setSaved(!saved);
    } catch (error) {
      console.error('Error saving post:', error);
    }
  };
  
  const addComment = (comment: Comment) => {
    setComments(prev => [comment, ...prev]);
    setCommentsCount(prev => prev + 1);
  };
  
  if (loading) {
    return (
      <View style={[styles.loadingContainer, { backgroundColor: colors.background }]}>
        <ActivityIndicator size="large" color={colors.primary} />
      </View>
    );
  }
  
  if (!post) {
    return (
      <View style={[styles.errorContainer, { backgroundColor: colors.background }]}>
        <Text style={[styles.errorText, { color: colors.text }]}>Post not found</Text>
        <TouchableOpacity
          style={[styles.backButton, { backgroundColor: colors.primary }]}
          onPress={() => router.back()}
        >
          <Text style={styles.backButtonText}>Go Back</Text>
        </TouchableOpacity>
      </View>
    );
  }

  return (
    <>
      <Stack.Screen options={{ 
        headerShown: true,
        headerTitle: '',
        headerShadowVisible: false,
        headerStyle: { backgroundColor: colors.background },
        headerLeft: () => (
          <TouchableOpacity onPress={() => router.back()} style={{ padding: 8 }}>
            <ChevronLeft size={24} color={colors.text} />
          </TouchableOpacity>
        ),
        headerRight: () => (
          <View style={{ flexDirection: 'row' }}>
            <TouchableOpacity onPress={handleSave} style={{ marginRight: 16, padding: 8 }}>
              <Bookmark size={24} color={saved ? colors.primary : colors.text} fill={saved ? colors.primary : 'transparent'} />
            </TouchableOpacity>
            <TouchableOpacity style={{ padding: 8 }}>
              <Share2 size={24} color={colors.text} />
            </TouchableOpacity>
          </View>
        ),
      }} />
      
      <View style={[styles.container, { backgroundColor: colors.background }]}>
        <ScrollView 
          contentContainerStyle={styles.scrollContent} 
          showsVerticalScrollIndicator={false}
        >
          {post.coverImage ? (
            <Image
              source={{ uri: post.coverImage }}
              style={styles.coverImage}
              contentFit="cover"
            />
          ) : null}
          
          <View style={styles.content}>
            <View style={styles.categoryContainer}>
              <Text style={[styles.category, { backgroundColor: colors.primary }]}>
                {post.category}
              </Text>
            </View>
            
            <Text style={[styles.title, { color: colors.text }]}>
              {post.title}
            </Text>
            
            <View style={styles.authorRow}>
              <Image
                source={{ uri: post.author?.avatar || 'https://via.placeholder.com/40' }}
                style={styles.authorImage}
              />
              <View style={styles.authorInfo}>
                <Text style={[styles.authorName, { color: colors.text }]}>
                  {post.author?.name || 'Unknown Author'}
                </Text>
                <Text style={[styles.postDate, { color: colors.textSecondary }]}>
                  {new Date(post.createdAt).toLocaleDateString('en-US', { 
                    year: 'numeric', 
                    month: 'short', 
                    day: 'numeric' 
                  })}
                </Text>
              </View>
            </View>
            
            <Text style={[styles.postText, { color: colors.text }]}>
              {post.content}
            </Text>
            
            <View style={[styles.actionsBar, { borderColor: colors.border }]}>
              <TouchableOpacity 
                style={styles.actionButton}
                onPress={handleLike}
              >
                <Heart 
                  size={22} 
                  color={liked ? '#EF4444' : colors.textSecondary} 
                  fill={liked ? '#EF4444' : 'transparent'}
                />
                <Text style={[styles.actionText, { color: colors.textSecondary }]}>
                  {likesCount}
                </Text>
              </TouchableOpacity>
              
              <TouchableOpacity 
                style={styles.actionButton}
                onPress={() => setShowComments(!showComments)}
              >
                <MessageCircle size={22} color={colors.textSecondary} />
                <Text style={[styles.actionText, { color: colors.textSecondary }]}>
                  {commentsCount}
                </Text>
              </TouchableOpacity>
            </View>
            
            {showComments && (
              <View style={styles.commentsSection}>
                <Text style={[styles.commentsHeader, { color: colors.text }]}>
                  Comments ({commentsCount})
                </Text>
                <CommentInput postId={post.id} onCommentAdded={addComment} />
                <CommentList comments={comments} />
              </View>
            )}
          </View>
        </ScrollView>
        
        {!showComments && (
          <View style={[styles.bottomBar, { backgroundColor: colors.background, borderColor: colors.border }]}>
            <CommentInput postId={post.id} onCommentAdded={addComment} />
          </View>
        )}
      </View>
    </>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  errorContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 24,
  },
  errorText: {
    fontSize: 18,
    fontFamily: 'Inter-Medium',
    marginBottom: 16,
    textAlign: 'center',
  },
  backButton: {
    paddingVertical: 12,
    paddingHorizontal: 24,
    borderRadius: 8,
  },
  backButtonText: {
    color: 'white',
    fontSize: 16,
    fontFamily: 'Inter-SemiBold',
  },
  scrollContent: {
    flexGrow: 1,
  },
  coverImage: {
    width: '100%',
    height: 250,
  },
  content: {
    padding: 24,
  },
  categoryContainer: {
    marginBottom: 16,
  },
  category: {
    color: 'white',
    fontSize: 12,
    fontFamily: 'Inter-SemiBold',
    paddingHorizontal: 12,
    paddingVertical: 4,
    borderRadius: 16,
    alignSelf: 'flex-start',
  },
  title: {
    fontSize: 28,
    fontFamily: 'Merriweather-Bold',
    marginBottom: 16,
  },
  authorRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 24,
  },
  authorImage: {
    width: 40,
    height: 40,
    borderRadius: 20,
    marginRight: 12,
  },
  authorInfo: {
    flex: 1,
  },
  authorName: {
    fontSize: 16,
    fontFamily: 'Inter-SemiBold',
    marginBottom: 2,
  },
  postDate: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
  },
  postText: {
    fontSize: 16,
    fontFamily: 'Merriweather-Regular',
    lineHeight: 26,
  },
  actionsBar: {
    flexDirection: 'row',
    paddingVertical: 16,
    marginTop: 24,
    borderTopWidth: 1,
  },
  actionButton: {
    flexDirection: 'row',
    alignItems: 'center',
    marginRight: 24,
  },
  actionText: {
    marginLeft: 6,
    fontSize: 14,
    fontFamily: 'Inter-Medium',
  },
  commentsSection: {
    marginTop: 24,
  },
  commentsHeader: {
    fontSize: 18,
    fontFamily: 'Inter-SemiBold',
    marginBottom: 16,
  },
  bottomBar: {
    padding: 16,
    borderTopWidth: 1,
  },
});