import AsyncStorage from '@react-native-async-storage/async-storage';
import { Post, Comment } from '@/types';

// Mock data for testing purposes
const mockPosts: Post[] = [
  {
    id: 1,
    title: 'The Future of Web Development: Trends to Watch in 2025',
    content: 'Web development is evolving at a breakneck pace. From WebAssembly to AI-assisted coding, the landscape of development is changing rapidly. This article explores the most important trends that will shape the future of web development in 2025 and beyond.\n\nNew frameworks, tools, and technologies are emerging every day, making it easier for developers to create powerful, responsive, and feature-rich applications. The rise of edge computing, serverless architectures, and improved browser capabilities are opening new possibilities for what can be achieved on the web.\n\nDevelopers who stay ahead of these trends will be well-positioned to create the next generation of web experiences.',
    excerpt: 'Exploring the cutting-edge technologies and methodologies that will define web development in the coming years.',
    coverImage: 'https://images.pexels.com/photos/574071/pexels-photo-574071.jpeg',
    category: 'Technology',
    author: {
      id: '2',
      name: 'Alex Johnson',
      email: 'alex@example.com',
      avatar: 'https://images.pexels.com/photos/220453/pexels-photo-220453.jpeg',
    },
    createdAt: '2025-03-15T10:30:00Z',
    likesCount: 42,
    commentsCount: 7,
    isLiked: false,
    isSaved: false,
    comments: [
      {
        id: 1,
        postId: 1,
        user: {
          id: '3',
          name: 'Sarah Miller',
          avatar: 'https://images.pexels.com/photos/774909/pexels-photo-774909.jpeg',
        },
        content: 'Great insights! I particularly agree with your points about WebAssembly and its potential impact.',
        createdAt: '2025-03-16T14:22:00Z',
      },
      {
        id: 2,
        postId: 1,
        user: {
          id: '4',
          name: 'David Wilson',
          avatar: 'https://images.pexels.com/photos/1222271/pexels-photo-1222271.jpeg',
        },
        content: 'I think you missed the importance of Progressive Web Apps. They\'re becoming more critical for user engagement.',
        createdAt: '2025-03-16T15:45:00Z',
      }
    ]
  },
  {
    id: 2,
    title: 'Mindfulness in the Digital Age: Finding Balance',
    content: 'In today\'s hyper-connected world, maintaining mindfulness has become increasingly challenging. This article explores practical techniques for staying present and focused despite the constant distractions of modern technology.\n\nFrom meditation apps to digital detoxes, there are many strategies that can help us reclaim our attention and mental wellbeing. We\'ll explore how to create healthy boundaries with technology while still benefiting from the amazing tools available to us.\n\nThe goal isn\'t to reject technology, but to develop a more intentional relationship with our devices and the digital world.',
    excerpt: 'How to stay present and focused in a world of constant digital distractions and information overload.',
    coverImage: 'https://images.pexels.com/photos/2908175/pexels-photo-2908175.jpeg',
    category: 'Health',
    author: {
      id: '5',
      name: 'Emma Chen',
      email: 'emma@example.com',
      avatar: 'https://images.pexels.com/photos/415829/pexels-photo-415829.jpeg',
    },
    createdAt: '2025-03-12T08:45:00Z',
    likesCount: 38,
    commentsCount: 5,
    isLiked: true,
    isSaved: false,
    comments: []
  },
  {
    id: 3,
    title: 'Sustainable Travel: Exploring the World Responsibly',
    content: 'As global tourism rebounds, the importance of sustainable travel practices has never been more apparent. This article provides actionable advice for minimizing your environmental footprint while still enjoying enriching travel experiences.\n\nFrom choosing eco-friendly accommodations to supporting local communities, there are many ways to make your travels more sustainable. We\'ll explore how to plan trips that are not only memorable but also responsible.\n\nSustainable travel isn\'t about sacrifice—it\'s about making thoughtful choices that enhance your experience while preserving destinations for future generations.',
    excerpt: 'Discover how to explore the world while minimizing your environmental impact and supporting local communities.',
    coverImage: 'https://images.pexels.com/photos/2662116/pexels-photo-2662116.jpeg',
    category: 'Travel',
    author: {
      id: '6',
      name: 'Marco Torres',
      email: 'marco@example.com',
      avatar: 'https://images.pexels.com/photos/614810/pexels-photo-614810.jpeg',
    },
    createdAt: '2025-03-10T16:20:00Z',
    likesCount: 56,
    commentsCount: 12,
    isLiked: false,
    isSaved: true,
    comments: []
  },
  {
    id: 4,
    title: 'The Science of Perfect Pastry: Tips from Master Bakers',
    content: 'Creating perfect pastry is equal parts science and art. In this deep dive, professional bakers share their secrets for achieving flaky, tender pastry every time.\n\nFrom the importance of temperature control to the specific types of butter that yield the best results, these insights will help you elevate your baking game. We\'ll cover techniques for various types of pastry, from puff to shortcrust.\n\nWith practice and these expert tips, you\'ll be creating bakery-quality pastries in your home kitchen.',
    excerpt: 'Master bakers reveal their closely guarded secrets for creating flaky, tender pastry every time.',
    coverImage: 'https://images.pexels.com/photos/2267873/pexels-photo-2267873.jpeg',
    category: 'Food',
    author: {
      id: '7',
      name: 'Julia Chang',
      email: 'julia@example.com',
      avatar: 'https://images.pexels.com/photos/1036623/pexels-photo-1036623.jpeg',
    },
    createdAt: '2025-03-08T09:15:00Z',
    likesCount: 47,
    commentsCount: 8,
    isLiked: false,
    isSaved: false,
    comments: []
  },
];

// Helper function to delay responses (simulates network latency)
const delay = (ms: number) => new Promise(resolve => setTimeout(resolve, ms));

// Fetch featured posts
export const fetchFeaturedPosts = async (): Promise<Post[]> => {
  await delay(800);
  return mockPosts.slice(0, 3);
};

// Fetch recent posts
export const fetchRecentPosts = async (): Promise<Post[]> => {
  await delay(600);
  return mockPosts;
};

// Fetch a post by ID
export const fetchPostById = async (id: number): Promise<Post> => {
  await delay(500);
  const post = mockPosts.find(post => post.id === id);
  
  if (!post) {
    throw new Error('Post not found');
  }
  
  return post;
};

// Search posts
export const searchPosts = async (query: string, categories: string[] = []): Promise<Post[]> => {
  await delay(400);
  
  let filteredPosts = [...mockPosts];
  
  // Filter by query
  if (query) {
    const lowerCaseQuery = query.toLowerCase();
    filteredPosts = filteredPosts.filter(
      post => 
        post.title.toLowerCase().includes(lowerCaseQuery) || 
        post.content.toLowerCase().includes(lowerCaseQuery)
    );
  }
  
  // Filter by categories
  if (categories.length > 0) {
    filteredPosts = filteredPosts.filter(post => 
      categories.includes(post.category)
    );
  }
  
  return filteredPosts;
};

// Fetch categories
export const fetchCategories = async (): Promise<string[]> => {
  await delay(300);
  return ['Technology', 'Health', 'Travel', 'Food', 'Lifestyle', 'Business'];
};

// Like a post
export const likePost = async (postId: number): Promise<void> => {
  await delay(300);
  // In a real app, you would make an API call to like the post
  return Promise.resolve();
};

// Save a post
export const savePost = async (postId: number): Promise<void> => {
  await delay(300);
  // In a real app, you would make an API call to save the post
  return Promise.resolve();
};

// Fetch saved posts
export const fetchSavedPosts = async (): Promise<Post[]> => {
  await delay(500);
  return mockPosts.filter(post => post.isSaved);
};

// Create a new post
export const createPost = async (postData: Partial<Post>): Promise<Post> => {
  await delay(1000);
  
  // In a real app, you would send this data to your backend
  const newPost: Post = {
    id: Math.floor(Math.random() * 1000) + 10,
    title: postData.title || '',
    content: postData.content || '',
    coverImage: postData.coverImage || '',
    category: postData.category || '',
    author: {
      id: '1',
      name: 'John Doe',
      email: 'john@example.com',
      avatar: 'https://images.pexels.com/photos/220453/pexels-photo-220453.jpeg',
    },
    createdAt: new Date().toISOString(),
    likesCount: 0,
    commentsCount: 0,
    isLiked: false,
    isSaved: false,
    comments: [],
  };
  
  return newPost;
};

// Add a comment to a post
export const addComment = async (postId: number, content: string): Promise<Comment> => {
  await delay(500);
  
  // In a real app, you would send this data to your backend
  const newComment: Comment = {
    id: Math.floor(Math.random() * 1000) + 10,
    postId,
    user: {
      id: '1',
      name: 'John Doe',
      avatar: 'https://images.pexels.com/photos/220453/pexels-photo-220453.jpeg',
    },
    content,
    createdAt: new Date().toISOString(),
  };
  
  return newComment;
};