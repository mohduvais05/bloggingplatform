import { useState, useEffect } from 'react';
import { View, Text, StyleSheet, FlatList, TouchableOpacity } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useRouter } from 'expo-router';
import { useTheme } from '@/hooks/useTheme';
import { fetchSavedPosts } from '@/api/posts';
import { Post } from '@/types';
import SavedPostCard from '@/components/SavedPostCard';
import { Bookmark } from 'lucide-react-native';

export default function SavedScreen() {
  const [savedPosts, setSavedPosts] = useState<Post[]>([]);
  const [loading, setLoading] = useState(true);
  
  const { colors } = useTheme();
  const router = useRouter();
  
  useEffect(() => {
    loadSavedPosts();
  }, []);
  
  const loadSavedPosts = async () => {
    setLoading(true);
    try {
      const posts = await fetchSavedPosts();
      setSavedPosts(posts);
    } catch (error) {
      console.error('Error loading saved posts:', error);
    } finally {
      setLoading(false);
    }
  };
  
  const removeSavedPost = (postId: number) => {
    setSavedPosts(prev => prev.filter(post => post.id !== postId));
  };
  
  const renderEmptyState = () => (
    <View style={styles.emptyContainer}>
      <Bookmark size={64} color={colors.textSecondary} />
      <Text style={[styles.emptyTitle, { color: colors.text }]}>No saved posts yet</Text>
      <Text style={[styles.emptySubtitle, { color: colors.textSecondary }]}>
        Articles you save will appear here for easy access
      </Text>
      <TouchableOpacity
        style={[styles.browseButton, { backgroundColor: colors.primary }]}
        onPress={() => router.push('/explore')}
      >
        <Text style={styles.browseButtonText}>Browse Articles</Text>
      </TouchableOpacity>
    </View>
  );

  return (
    <SafeAreaView style={[styles.container, { backgroundColor: colors.background }]}>
      <Text style={[styles.headerTitle, { color: colors.text }]}>Saved Posts</Text>
      
      <FlatList
        data={savedPosts}
        renderItem={({ item }) => (
          <SavedPostCard 
            post={item} 
            onPress={() => router.push(`/post/${item.id}`)}
            onRemove={() => removeSavedPost(item.id)} 
          />
        )}
        keyExtractor={(item) => item.id.toString()}
        contentContainerStyle={styles.listContainer}
        ListEmptyComponent={renderEmptyState}
        showsVerticalScrollIndicator={false}
      />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  headerTitle: {
    fontSize: 28,
    fontFamily: 'Inter-Bold',
    marginTop: 16,
    marginBottom: 24,
    paddingHorizontal: 24,
  },
  listContainer: {
    paddingHorizontal: 24,
    paddingBottom: 24,
    flexGrow: 1,
  },
  emptyContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    paddingHorizontal: 24,
    paddingBottom: 80,
  },
  emptyTitle: {
    fontSize: 20,
    fontFamily: 'Inter-SemiBold',
    marginTop: 16,
    marginBottom: 8,
  },
  emptySubtitle: {
    fontSize: 16,
    fontFamily: 'Inter-Regular',
    textAlign: 'center',
    marginBottom: 32,
  },
  browseButton: {
    paddingVertical: 12,
    paddingHorizontal: 24,
    borderRadius: 8,
  },
  browseButtonText: {
    color: 'white',
    fontSize: 16,
    fontFamily: 'Inter-SemiBold',
  },
});