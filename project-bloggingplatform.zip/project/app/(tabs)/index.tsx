import { useEffect, useState } from 'react';
import { View, Text, StyleSheet, FlatList, TouchableOpacity, RefreshControl } from 'react-native';
import { useRouter } from 'expo-router';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Image } from 'expo-image';
import { Heart, MessageCircle, Menu, BellRing } from 'lucide-react-native';
import { useTheme } from '@/hooks/useTheme';
import { useAuth } from '@/hooks/useAuth';
import { fetchFeaturedPosts, fetchRecentPosts } from '@/api/posts';
import { Post } from '@/types';
import FeaturedPostCard from '@/components/FeaturedPostCard';
import PostCard from '@/components/PostCard';

export default function HomeScreen() {
  const [featuredPosts, setFeaturedPosts] = useState<Post[]>([]);
  const [recentPosts, setRecentPosts] = useState<Post[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  
  const { user } = useAuth();
  const { colors } = useTheme();
  const router = useRouter();
  
  useEffect(() => {
    loadData();
  }, []);
  
  const loadData = async () => {
    setLoading(true);
    try {
      const [featuredData, recentData] = await Promise.all([
        fetchFeaturedPosts(),
        fetchRecentPosts()
      ]);
      
      setFeaturedPosts(featuredData);
      setRecentPosts(recentData);
    } catch (error) {
      console.error('Error loading posts:', error);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };
  
  const onRefresh = () => {
    setRefreshing(true);
    loadData();
  };
  
  const renderFeaturedItem = ({ item }: { item: Post }) => (
    <FeaturedPostCard post={item} onPress={() => router.push(`/post/${item.id}`)} />
  );
  
  const renderHeader = () => (
    <View style={styles.headerContent}>
      <Text style={[styles.welcomeText, { color: colors.textSecondary }]}>
        Hello, {user?.name?.split(' ')[0] || 'Reader'}
      </Text>
      <Text style={[styles.headerTitle, { color: colors.text }]}>
        Discover stories that matter
      </Text>
      
      {featuredPosts.length > 0 && (
        <View style={styles.featuredSection}>
          <View style={styles.sectionHeader}>
            <Text style={[styles.sectionTitle, { color: colors.text }]}>Featured</Text>
            <TouchableOpacity onPress={() => router.push('/featured')}>
              <Text style={[styles.viewAllText, { color: colors.primary }]}>View all</Text>
            </TouchableOpacity>
          </View>
          
          <FlatList
            data={featuredPosts}
            horizontal
            showsHorizontalScrollIndicator={false}
            renderItem={renderFeaturedItem}
            keyExtractor={(item) => item.id.toString()}
            contentContainerStyle={styles.featuredList}
          />
        </View>
      )}
      
      <View style={styles.recentSection}>
        <View style={styles.sectionHeader}>
          <Text style={[styles.sectionTitle, { color: colors.text }]}>Recent Posts</Text>
          <TouchableOpacity onPress={() => router.push('/explore')}>
            <Text style={[styles.viewAllText, { color: colors.primary }]}>View all</Text>
          </TouchableOpacity>
        </View>
      </View>
    </View>
  );
  
  return (
    <SafeAreaView style={[styles.container, { backgroundColor: colors.background }]}>
      <View style={styles.header}>
        <Text style={[styles.logoText, { color: colors.primary }]}>Blogify</Text>
        <View style={styles.headerRight}>
          <TouchableOpacity style={styles.iconButton}>
            <BellRing size={24} color={colors.text} />
          </TouchableOpacity>
          <TouchableOpacity style={styles.iconButton}>
            <Menu size={24} color={colors.text} />
          </TouchableOpacity>
        </View>
      </View>
      
      <FlatList
        data={recentPosts}
        renderItem={({ item }) => (
          <PostCard post={item} onPress={() => router.push(`/post/${item.id}`)} />
        )}
        keyExtractor={(item) => item.id.toString()}
        ListHeaderComponent={renderHeader}
        contentContainerStyle={styles.listContainer}
        showsVerticalScrollIndicator={false}
        refreshControl={
          <RefreshControl
            refreshing={refreshing}
            onRefresh={onRefresh}
            tintColor={colors.primary}
            colors={[colors.primary]}
          />
        }
      />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 24,
    paddingVertical: 16,
  },
  logoText: {
    fontFamily: 'Inter-Bold',
    fontSize: 24,
  },
  headerRight: {
    flexDirection: 'row',
  },
  iconButton: {
    marginLeft: 16,
  },
  listContainer: {
    paddingBottom: 24,
  },
  headerContent: {
    paddingHorizontal: 24,
    paddingTop: 8,
    paddingBottom: 16,
  },
  welcomeText: {
    fontFamily: 'Inter-Regular',
    fontSize: 14,
    marginBottom: 4,
  },
  headerTitle: {
    fontFamily: 'Inter-Bold',
    fontSize: 24,
    marginBottom: 24,
  },
  featuredSection: {
    marginBottom: 24,
  },
  recentSection: {
    marginBottom: 16,
  },
  sectionHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 16,
  },
  sectionTitle: {
    fontFamily: 'Inter-SemiBold',
    fontSize: 18,
  },
  viewAllText: {
    fontFamily: 'Inter-Medium',
    fontSize: 14,
  },
  featuredList: {
    paddingLeft: 0,
    paddingRight: 8,
  },
});