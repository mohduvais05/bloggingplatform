import { View, Text, StyleSheet, FlatList } from 'react-native';
import { Image } from 'expo-image';
import { Comment } from '@/types';
import { useTheme } from '@/hooks/useTheme';

interface CommentListProps {
  comments: Comment[];
}

export default function CommentList({ comments }: CommentListProps) {
  const { colors } = useTheme();
  
  const renderCommentItem = ({ item }: { item: Comment }) => (
    <View style={[styles.commentContainer, { borderBottomColor: colors.border }]}>
      <Image
        source={{ uri: item.user?.avatar || 'https://via.placeholder.com/40' }}
        style={styles.commentUserImage}
      />
      <View style={styles.commentContent}>
        <View style={styles.commentHeader}>
          <Text style={[styles.commentUserName, { color: colors.text }]}>
            {item.user?.name || 'Anonymous User'}
          </Text>
          <Text style={[styles.commentTime, { color: colors.textSecondary }]}>
            {new Date(item.createdAt).toLocaleDateString('en-US', {
              month: 'short',
              day: 'numeric',
              hour: '2-digit',
              minute: '2-digit'
            })}
          </Text>
        </View>
        <Text style={[styles.commentText, { color: colors.text }]}>
          {item.content}
        </Text>
      </View>
    </View>
  );
  
  if (comments.length === 0) {
    return (
      <View style={styles.emptyContainer}>
        <Text style={[styles.emptyText, { color: colors.textSecondary }]}>
          No comments yet. Be the first to comment!
        </Text>
      </View>
    );
  }
  
  return (
    <FlatList
      data={comments}
      renderItem={renderCommentItem}
      keyExtractor={(item) => item.id.toString()}
      contentContainerStyle={styles.listContainer}
    />
  );
}

const styles = StyleSheet.create({
  listContainer: {
    paddingTop: 8,
  },
  commentContainer: {
    flexDirection: 'row',
    paddingVertical: 16,
    borderBottomWidth: 1,
  },
  commentUserImage: {
    width: 40,
    height: 40,
    borderRadius: 20,
    marginRight: 12,
  },
  commentContent: {
    flex: 1,
  },
  commentHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 4,
  },
  commentUserName: {
    fontSize: 14,
    fontFamily: 'Inter-SemiBold',
  },
  commentTime: {
    fontSize: 12,
    fontFamily: 'Inter-Regular',
  },
  commentText: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    lineHeight: 20,
  },
  emptyContainer: {
    padding: 24,
    alignItems: 'center',
  },
  emptyText: {
    fontFamily: 'Inter-Regular',
    fontSize: 14,
    textAlign: 'center',
  },
});