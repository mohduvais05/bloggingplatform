import { StyleSheet, TouchableOpacity, Text, View } from 'react-native';
import { Image } from 'expo-image';
import { Post } from '@/types';
import { useTheme } from '@/hooks/useTheme';
import { Heart, MessageCircle } from 'lucide-react-native';

interface PostCardProps {
  post: Post;
  onPress: () => void;
}

export default function PostCard({ post, onPress }: PostCardProps) {
  const { colors } = useTheme();
  
  return (
    <TouchableOpacity 
      style={[styles.container, { backgroundColor: colors.cardBackground, borderColor: colors.border }]}
      activeOpacity={0.8}
      onPress={onPress}
    >
      <View style={styles.contentContainer}>
        <View style={styles.postInfo}>
          <Text style={[styles.category, { color: colors.primary }]}>
            {post.category}
          </Text>
          <Text style={[styles.title, { color: colors.text }]} numberOfLines={2}>
            {post.title}
          </Text>
          <Text style={[styles.excerpt, { color: colors.textSecondary }]} numberOfLines={2}>
            {post.excerpt || post.content.substring(0, 100) + '...'}
          </Text>
          
          <View style={styles.postMeta}>
            <View style={styles.authorContainer}>
              <Image
                source={{ uri: post.author?.avatar || 'https://via.placeholder.com/24' }}
                style={styles.authorImage}
              />
              <Text style={[styles.authorName, { color: colors.textSecondary }]}>
                {post.author?.name || 'Unknown Author'}
              </Text>
            </View>
            
            <View style={styles.statsContainer}>
              <View style={styles.statItem}>
                <Heart size={14} color={colors.textSecondary} />
                <Text style={[styles.statText, { color: colors.textSecondary }]}>
                  {post.likesCount || 0}
                </Text>
              </View>
              <View style={styles.statItem}>
                <MessageCircle size={14} color={colors.textSecondary} />
                <Text style={[styles.statText, { color: colors.textSecondary }]}>
                  {post.commentsCount || 0}
                </Text>
              </View>
            </View>
          </View>
        </View>
        
        {post.coverImage && (
          <Image
            source={{ uri: post.coverImage }}
            style={styles.thumbnail}
            contentFit="cover"
          />
        )}
      </View>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  container: {
    borderRadius: 12,
    marginBottom: 16,
    borderWidth: 1,
    overflow: 'hidden',
  },
  contentContainer: {
    flexDirection: 'row',
    padding: 16,
  },
  postInfo: {
    flex: 1,
    marginRight: 12,
  },
  category: {
    fontSize: 12,
    fontFamily: 'Inter-SemiBold',
    marginBottom: 4,
  },
  title: {
    fontSize: 16,
    fontFamily: 'Merriweather-Bold',
    marginBottom: 8,
  },
  excerpt: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    marginBottom: 12,
    lineHeight: 20,
  },
  postMeta: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  authorContainer: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  authorImage: {
    width: 24,
    height: 24,
    borderRadius: 12,
    marginRight: 8,
  },
  authorName: {
    fontSize: 12,
    fontFamily: 'Inter-Medium',
  },
  statsContainer: {
    flexDirection: 'row',
  },
  statItem: {
    flexDirection: 'row',
    alignItems: 'center',
    marginLeft: 12,
  },
  statText: {
    fontSize: 12,
    fontFamily: 'Inter-Regular',
    marginLeft: 4,
  },
  thumbnail: {
    width: 80,
    height: 80,
    borderRadius: 8,
  },
});