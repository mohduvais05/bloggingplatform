import { createContext, useState, useEffect, ReactNode } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { User } from '@/types';

interface AuthContextType {
  user: User | null;
  isAuthenticated: boolean;
  login: (email: string, password: string) => Promise<void>;
  register: (name: string, email: string, password: string) => Promise<void>;
  logout: () => Promise<void>;
  updateUser: (userData: Partial<User>) => Promise<void>;
}

export const AuthContext = createContext<AuthContextType>({
  user: null,
  isAuthenticated: false,
  login: async () => {},
  register: async () => {},
  logout: async () => {},
  updateUser: async () => {},
});

interface AuthProviderProps {
  children: ReactNode;
}

export const AuthProvider = ({ children }: AuthProviderProps) => {
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  
  useEffect(() => {
    // Check for stored user data on app start
    const loadUser = async () => {
      try {
        const userJson = await AsyncStorage.getItem('user');
        const token = await AsyncStorage.getItem('token');
        
        if (userJson && token) {
          setUser(JSON.parse(userJson));
        }
      } catch (error) {
        console.error('Error loading auth state:', error);
      } finally {
        setIsLoading(false);
      }
    };
    
    loadUser();
  }, []);
  
  const login = async (email: string, password: string) => {
    // In a real app, you would make an API call here
    // For now, we'll simulate a successful login
    
    // Simulate API delay
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    const mockUser: User = {
      id: '1',
      name: 'John Doe',
      email,
      bio: 'Passionate writer and avid reader. Sharing my thoughts with the world.',
      avatar: 'https://images.pexels.com/photos/220453/pexels-photo-220453.jpeg',
      createdAt: new Date().toISOString(),
    };
    
    // Store user data
    await AsyncStorage.setItem('user', JSON.stringify(mockUser));
    await AsyncStorage.setItem('token', 'mock-token-12345');
    
    setUser(mockUser);
  };
  
  const register = async (name: string, email: string, password: string) => {
    // In a real app, you would make an API call here
    // For now, we'll simulate a successful registration
    
    // Simulate API delay
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    const newUser: User = {
      id: '1',
      name,
      email,
      bio: '',
      avatar: 'https://images.pexels.com/photos/1681010/pexels-photo-1681010.jpeg',
      createdAt: new Date().toISOString(),
    };
    
    // Store user data
    await AsyncStorage.setItem('user', JSON.stringify(newUser));
    await AsyncStorage.setItem('token', 'mock-token-12345');
    
    setUser(newUser);
  };
  
  const logout = async () => {
    // Clear stored user data
    await AsyncStorage.removeItem('user');
    await AsyncStorage.removeItem('token');
    
    setUser(null);
  };
  
  const updateUser = async (userData: Partial<User>) => {
    if (!user) return;
    
    const updatedUser = { ...user, ...userData };
    
    // Update stored user data
    await AsyncStorage.setItem('user', JSON.stringify(updatedUser));
    
    setUser(updatedUser);
  };
  
  return (
    <AuthContext.Provider
      value={{
        user,
        isAuthenticated: !!user,
        login,
        register,
        logout,
        updateUser,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};