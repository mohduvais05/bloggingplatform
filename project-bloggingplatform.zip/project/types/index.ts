export interface User {
  id: string;
  name: string;
  email: string;
  bio?: string;
  avatar?: string;
  createdAt: string;
}

export interface Author {
  id: string;
  name: string;
  email: string;
  avatar?: string;
}

export interface Comment {
  id: number;
  postId: number;
  user?: {
    id: string;
    name: string;
    avatar?: string;
  };
  content: string;
  createdAt: string;
}

export interface Post {
  id: number;
  title: string;
  content: string;
  excerpt?: string;
  coverImage?: string;
  category: string;
  author?: Author;
  createdAt: string;
  likesCount?: number;
  commentsCount?: number;
  isLiked?: boolean;
  isSaved?: boolean;
  comments?: Comment[];
}